Following files are for question 1:
hw3part1d.m is for part (d).
hw3part1e.m is for part (e).
hw3part1f.m is for part (f).

Following files are for question 4:
hw3part4.m
