function [ predictedValue ] = mylinridgeregeval( X, weights )
    predictedValue = X * weights;