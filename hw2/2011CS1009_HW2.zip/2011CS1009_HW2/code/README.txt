Execution Script for Question 1 is named HW2Q1.m
Execution Script for Question 3 is named HW2Q3.m
Rest of the scripts are named as per mentioned in the Homework.
